<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<style>
.checkout-page { max-width: 1050px; margin: 32px auto; padding: 0 18px; display: grid; grid-template-columns: minmax(0, 1.2fr) minmax(280px, .8fr); gap: 24px; color: #20252d; }
.checkout-panel { padding: 24px; background: white; border: 1px solid #e5e9ef; border-radius: 12px; }
.checkout-panel h1, .checkout-panel h2 { margin-top: 0; }
.checkout-error { padding: 12px 14px; color: #842029; background: #f8d7da; border-radius: 7px; }
.checkout-field { display: block; margin: 15px 0; font-weight: 600; }
.checkout-field input, .checkout-field textarea { display: block; width: 100%; margin-top: 7px; padding: 11px; border: 1px solid #cfd6df; border-radius: 7px; font: inherit; box-sizing: border-box; }
.checkout-field textarea { min-height: 90px; resize: vertical; }
.checkout-method { padding: 12px; background: #f2f7f5; border-radius: 7px; color: #176044; }
.checkout-row { display: flex; justify-content: space-between; gap: 12px; padding: 9px 0; border-bottom: 1px solid #edf0f4; }
.checkout-total { font-size: 20px; font-weight: 700; color: #b42318; margin-top: 16px; }
.checkout-btn { width: 100%; padding: 12px; margin-top: 18px; border: 0; border-radius: 7px; background: #16805d; color: #fff; font-weight: 700; font-size: 16px; cursor: pointer; }
.checkout-back { display: inline-block; margin-top: 16px; color: #1769aa; }
@media(max-width: 760px) { .checkout-page { grid-template-columns: 1fr; } }
</style>

<main class="checkout-page">
	<section class="checkout-panel">
		<h1>Thông tin nhận hàng</h1>
		<c:if test="${not empty checkoutMessage}"><p class="checkout-error" role="alert"><c:out value="${checkoutMessage}"/></p></c:if>
		<form method="post" action="${pageContext.request.contextPath}/cart/checkout">
			<label class="checkout-field">Họ và tên *<input name="customerName" value="<c:out value='${checkoutName}'/>" maxlength="100" autocomplete="name" required></label>
			<label class="checkout-field">Số điện thoại *<input name="phone" value="<c:out value='${checkoutPhone}'/>" maxlength="20" autocomplete="tel" required></label>
			<label class="checkout-field">Địa chỉ giao hàng *<textarea name="address" maxlength="500" autocomplete="street-address" required><c:out value="${checkoutAddress}"/></textarea></label>
			<label class="checkout-field">Ghi chú<textarea name="note" maxlength="1000"><c:out value="${checkoutNote}"/></textarea></label>
			<div class="checkout-method"><strong>Phương thức thanh toán</strong><br>Thanh toán khi nhận hàng (COD)</div>
			<button class="checkout-btn" type="submit">Đặt hàng</button>
		</form>
		<a class="checkout-back" href="${pageContext.request.contextPath}/cart">Quay lại giỏ hàng</a>
	</section>
	<aside class="checkout-panel">
		<h2>Đơn hàng</h2>
		<c:forEach var="item" items="${cartItems}">
			<div class="checkout-row"><span><c:out value="${item.video.title}"/> × ${item.quantity}</span><strong><fmt:formatNumber value="${item.lineTotal}" type="number" groupingUsed="true" maxFractionDigits="0"/> &#8363;</strong></div>
		</c:forEach>
		<div class="checkout-total">Tổng thanh toán: <fmt:formatNumber value="${cartTotal}" type="number" groupingUsed="true" maxFractionDigits="0"/> &#8363;</div>
	</aside>
</main>
