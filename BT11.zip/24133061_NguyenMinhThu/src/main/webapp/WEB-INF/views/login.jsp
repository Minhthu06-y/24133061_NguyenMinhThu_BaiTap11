<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Đăng nhập</title>
</head>

<body>

	<h2>ĐĂNG NHẬP</h2>

	<form action="${pageContext.request.contextPath}/login" method="post">

		<p>
			Tài khoản: <input type="text" name="username" required>
		</p>

		<p>
			Mật khẩu: <input type="password" name="password" required>
		</p>

		<button type="submit">Đăng nhập</button>

	</form>

	<p style="color: red;">${error}</p>

	<p>
		Chưa có tài khoản? <a
			href="${pageContext.request.contextPath}/register"> Đăng ký </a>
	</p>

</body>
</html>