<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<title>Xác nhận OTP</title>
</head>

<body>

	<h2>XÁC NHẬN OTP</h2>

	<p>Mã OTP đã được gửi vào email của bạn.</p>

	<p style="color: red;">${error}</p>

	<form action="${pageContext.request.contextPath}/verify-otp"
		method="post">

		<p>
			Nhập mã OTP: <input type="text" name="otp" maxlength="6" required>
		</p>

		<button type="submit">Xác nhận</button>

	</form>

</body>
</html>