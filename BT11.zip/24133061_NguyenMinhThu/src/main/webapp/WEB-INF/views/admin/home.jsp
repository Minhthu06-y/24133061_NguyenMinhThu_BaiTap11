<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<title>Trang quản trị</title>
</head>

<body>

	<h1>TRANG QUẢN TRỊ</h1>

	<p>Xin chào, ${sessionScope.account.fullname}</p>

	<hr>

	<h3>Quản lý hệ thống</h3>

	<p>
		<a href="${pageContext.request.contextPath}/users"> Quản lý Users
		</a>
	</p>

	<p>
		<a href="${pageContext.request.contextPath}/logout"> Đăng xuất </a>
	</p>

</body>
</html>