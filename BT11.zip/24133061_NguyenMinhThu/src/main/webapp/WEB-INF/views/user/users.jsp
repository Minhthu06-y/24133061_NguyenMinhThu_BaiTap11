<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<title>Quản lý người dùng</title>
</head>

<body>

	<h2>QUẢN LÝ NGƯỜI DÙNG</h2>

	<p>
		<a href="${pageContext.request.contextPath}/admin/home"> ← Trang
			quản trị </a>
	</p>

	<p>
		<a href="${pageContext.request.contextPath}/users?action=add"> +
			Thêm người dùng </a>
	</p>

	<br>

	<table border="1" cellpadding="8" cellspacing="0">

		<tr>
			<th>STT</th>
			<th>Username</th>
			<th>Họ tên</th>
			<th>Số điện thoại</th>
			<th>Email</th>
			<th>Quyền</th>
			<th>Trạng thái</th>
			<th>Thao tác</th>
		</tr>

		<c:forEach var="user" items="${users}" varStatus="status">

			<tr>

				<td>${status.index + 1}</td>

				<td>${user.username}</td>

				<td>${user.fullname}</td>

				<td>${user.phone}</td>

				<td>${user.email}</td>

				<td><c:choose>

						<c:when test="${user.admin}">
                        Admin
                    </c:when>

						<c:otherwise>
                        User
                    </c:otherwise>

					</c:choose></td>

				<td><c:choose>

						<c:when test="${user.active}">
                        Hoạt động
                    </c:when>

						<c:otherwise>
                        Khóa
                    </c:otherwise>

					</c:choose></td>

				<td><a
					href="${pageContext.request.contextPath}/users?action=edit&username=${user.username}">
						Sửa </a> | <a
					href="${pageContext.request.contextPath}/users?action=delete&username=${user.username}"
					onclick="return confirm('Bạn có chắc muốn xóa user này?');">
						Xóa </a></td>

			</tr>

		</c:forEach>

	</table>

	<br>

	<!-- PHÂN TRANG -->

	<div>

		<c:if test="${currentPage > 1}">

			<a
				href="${pageContext.request.contextPath}/users?page=${currentPage - 1}">
				← Trước </a>

		</c:if>

		&nbsp;&nbsp; Trang ${currentPage} / ${totalPages} &nbsp;&nbsp;

		<c:if test="${currentPage < totalPages}">

			<a
				href="${pageContext.request.contextPath}/users?page=${currentPage + 1}">
				Sau → </a>

		</c:if>

	</div>

</body>
</html>