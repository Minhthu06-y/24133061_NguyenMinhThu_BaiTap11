<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<title>Thông tin người dùng</title>
</head>

<body>

	<h2>${user == null ? "THÊM NGƯỜI DÙNG" : "SỬA NGƯỜI DÙNG"}</h2>

	<form action="${pageContext.request.contextPath}/users" method="post">

		<!-- ACTION -->

		<input type="hidden" name="action"
			value="${user == null ? 'insert' : 'update'}">


		<!-- USERNAME -->

		<p>
			<label>Username:</label> <input type="text" name="username"
				value="${user.username}" ${user != null ? "readonly" : ""} required>
		</p>


		<!-- PASSWORD -->

		<p>
			<label>Password:</label> <input type="password" name="password"
				value="${user.password}" required>
		</p>


		<!-- PHONE -->

		<p>
			<label>Phone:</label> <input type="text" name="phone"
				value="${user.phone}">
		</p>


		<!-- FULLNAME -->

		<p>
			<label>Họ tên:</label> <input type="text" name="fullname"
				value="${user.fullname}">
		</p>


		<!-- EMAIL -->

		<p>
			<label>Email:</label> <input type="email" name="email"
				value="${user.email}">
		</p>


		<!-- ADMIN -->

		<p>
			<label>Quyền:</label> <select name="admin">

				<option value="0" ${user == null || !user.admin ? "selected" : ""}>
					User</option>

				<option value="1" ${user != null && user.admin ? "selected" : ""}>
					Admin</option>

			</select>

		</p>


		<!-- ACTIVE -->

		<p>
			<label>Trạng thái:</label> <select name="active">

				<option value="1" ${user == null || user.active ? "selected" : ""}>
					Hoạt động</option>

				<option value="0" ${user != null && !user.active ? "selected" : ""}>
					Khóa</option>

			</select>

		</p>


		<br>

		<button type="submit">Lưu</button>

		&nbsp; <a href="${pageContext.request.contextPath}/users"> Hủy </a>

	</form>

</body>
</html>