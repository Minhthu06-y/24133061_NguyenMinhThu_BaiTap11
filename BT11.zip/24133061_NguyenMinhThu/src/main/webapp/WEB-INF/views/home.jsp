<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>


<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Trang chủ - Web Video</title>


<style>

/* =========================
   PAGE
========================= */
body {
	margin: 0;
	font-family: Arial, sans-serif;
	background: #f5f6fa;
}

/* =========================
   TITLE
========================= */
.page-title {
	text-align: center;
	margin: 30px 0;
	font-size: 28px;
}

/* =========================
   VIDEO GRID
========================= */
.video-container {
	max-width: 1200px;
	margin: 0 auto;
	padding: 0 20px 40px;
	display: grid;
	grid-template-columns: repeat(3, 1fr);
	gap: 25px;
}

/* =========================
   LINK
========================= */
.video-link {
	display: block;
	text-decoration: none;
	color: inherit;
}

/* =========================
   CARD
========================= */
.video-card {
	background: white;
	border-radius: 12px;
	overflow: hidden;
	box-shadow: 0 3px 10px rgba(0, 0, 0, 0.12);
	transition: 0.2s;
	cursor: pointer;
}

.video-card:hover {
	transform: translateY(-5px);
	box-shadow: 0 8px 18px rgba(0, 0, 0, 0.18);
}

/* =========================
   POSTER
========================= */
.video-poster {
	width: 100%;
	height: 220px;
	object-fit: cover;
	display: block;
}

/* =========================
   INFO
========================= */
.video-info {
	padding: 18px;
}

.video-title {
	margin: 0 0 12px;
	font-size: 21px;
}

.video-category {
	display: inline-block;
	padding: 6px 12px;
	background: #e8f0fe;
	color: #3367d6;
	border-radius: 20px;
	font-size: 13px;
}

.video-views {
	color: #777;
	font-size: 14px;
	margin: 14px 0;
}

.video-description {
	color: #555;
	line-height: 1.5;
	margin: 0;
}

/* =========================
   TABLET
========================= */
@media ( max-width : 900px) {
	.video-container {
		grid-template-columns: repeat(2, 1fr);
	}
}

/* =========================
   MOBILE
========================= */
@media ( max-width : 600px) {
	.video-container {
		grid-template-columns: 1fr;
	}
}
</style>

</head>


<body>


	<h2 class="page-title">🎬 Danh sách video</h2>


	<div class="video-container">


		<c:forEach var="video" items="${videos}">


			<!--
            TẠO URL DETAIL
            Ví dụ:
            /video/detail?id=VID002
        -->

			<c:url var="detailUrl" value="/video/detail">

				<c:param name="id" value="${video.videoId}" />

			</c:url>


			<!-- CARD CLICK ĐƯỢC -->

			<a href="${detailUrl}" class="video-link">


				<div class="video-card">


					<!-- POSTER -->

					<img class="video-poster"
						src="${pageContext.request.contextPath}/images/${video.poster}"
						alt="${video.title}">


					<!-- THÔNG TIN -->

					<div class="video-info">


						<h3 class="video-title">${video.title}</h3>


						<span class="video-category"> ${video.categoryName} </span>


						<p class="video-views">👁 Lượt xem: ${video.views}</p>


						<p class="video-description">${video.description}</p>


					</div>

				</div>

			</a>

		</c:forEach>


	</div>


</body>

</html>