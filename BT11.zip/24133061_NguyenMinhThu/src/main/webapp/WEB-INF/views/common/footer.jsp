<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<hr>

	<footer>
		<p>Họ tên: Nguyễn Minh Thư</p>
		<p>MSSV: 24133061</p>
		<p>Mã đề: 04</p>
	</footer>
</body>
</html>