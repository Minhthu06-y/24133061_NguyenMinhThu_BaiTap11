<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<title>WEB VIDEO</title>

<style>
<
style>body {
	margin: 0;
	font-family: Arial, sans-serif;
	background: #f5f6fa;
}

/* KHU VỰC NỘI DUNG */
.main-content {
	padding: 30px;
	min-height: 600px;
}

/* TIÊU ĐỀ */
.page-title {
	text-align: center;
	margin: 20px 0 30px;
	font-size: 28px;
}

/* 3 VIDEO TRÊN 1 HÀNG */
.video-container {
	max-width: 1200px;
	margin: 0 auto;
	display: grid;
	grid-template-columns: repeat(3, 1fr);
	gap: 25px;
	padding: 0 20px 40px;
}

/* CARD */
.video-card {
	background: white;
	border-radius: 12px;
	overflow: hidden;
	box-shadow: 0 3px 10px rgba(0, 0, 0, 0.12);
}

/* ẢNH */
.video-poster {
	width: 100%;
	height: 180px;
	object-fit: cover;
	display: block;
}

/* NỘI DUNG */
.video-info {
	padding: 16px;
}

.video-title {
	margin: 0 0 10px;
	font-size: 19px;
}

.video-category {
	display: inline-block;
	padding: 5px 10px;
	background: #e8f0fe;
	color: #3367d6;
	border-radius: 15px;
	font-size: 13px;
}

.video-views {
	color: #777;
	font-size: 14px;
	margin: 12px 0;
}

.video-description {
	color: #555;
	line-height: 1.5;
	margin: 0;
}

/* TABLET */
@media ( max-width : 900px) {
	.video-container {
		grid-template-columns: repeat(2, 1fr);
	}
}

/* ĐIỆN THOẠI */
@media ( max-width : 600px) {
	.video-container {
		grid-template-columns: 1fr;
	}
}
</style>
</head>

<body>

	<!-- HEADER -->
	<div class="header">
		<jsp:include page="/WEB-INF/views/common/header.jsp" />
	</div>


	<!-- NỘI DUNG TRANG -->
	<div class="main-content">

		<sitemesh:write property="body" />

	</div>


	<!-- FOOTER -->
	<div class="footer">
		<jsp:include page="/WEB-INF/views/common/footer.jsp" />
	</div>

</body>

</html>