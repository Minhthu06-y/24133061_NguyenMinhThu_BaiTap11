<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<div style="background: #222; padding: 15px 30px; margin-bottom: 20px;">

	<a href="${pageContext.request.contextPath}/home"
		style="color: white; text-decoration: none; margin-right: 25px;">
		Trang Chủ </a> <a href="${pageContext.request.contextPath}/video"
		style="color: white; text-decoration: none; margin-right: 25px;">
		Sản Phẩm </a> <a href="${pageContext.request.contextPath}/login"
		style="color: white; text-decoration: none; margin-right: 25px;">
		Đăng Nhập </a> <a href="${pageContext.request.contextPath}/admin/home"
		style="color: white; text-decoration: none;"> Trang Quản Trị </a>

	<a href="${pageContext.request.contextPath}/cart"
		style="color: white; text-decoration: none; margin-left: 25px;">
		Giỏ hàng (${empty sessionScope.cartCount ? 0 : sessionScope.cartCount}) </a>

</div>
