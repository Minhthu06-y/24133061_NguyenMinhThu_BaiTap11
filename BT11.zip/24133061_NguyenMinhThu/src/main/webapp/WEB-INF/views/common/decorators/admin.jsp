<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<title>Admin - Web Video</title>
</head>

<body>

	<h2>WEB VIDEO - ADMIN</h2>

	<hr>

	${body}

	<hr>

	<p>Họ tên: Nguyễn Minh Thư</p>

	<p>MSSV: 24133061</p>

	<p>Mã đề: 04</p>

</body>
</html>