<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<style>
* {
	box-sizing: border-box;
}

.video-page {
	width: 90%;
	max-width: 1200px;
	margin: 30px auto;
	font-family: Arial, sans-serif;
}

.page-title {
	text-align: center;
	margin-bottom: 30px;
}

.page-title h1 {
	margin: 0;
	font-size: 32px;
	color: #222;
}

.page-title p {
	color: #777;
	margin-top: 8px;
}

/* GRID */
.video-grid {
	display: grid;
	grid-template-columns: repeat(3, 1fr);
	gap: 25px;
}

/* CARD */
.video-card {
	background: white;
	border-radius: 12px;
	overflow: hidden;
	border: 1px solid #e5e5e5;
	box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
	transition: all 0.25s ease;
}

.video-card:hover {
	transform: translateY(-6px);
	box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
}

/* POSTER */
.poster-box {
	width: 100%;
	height: 190px;
	background: #f1f1f1;
	overflow: hidden;
}

.poster-box img {
	width: 100%;
	height: 100%;
	object-fit: cover;
	display: block;
}

.no-poster {
	width: 100%;
	height: 100%;
	display: flex;
	align-items: center;
	justify-content: center;
	color: #999;
	font-size: 15px;
}

/* CONTENT */
.video-content {
	padding: 18px;
}

.video-title {
	font-size: 19px;
	font-weight: bold;
	margin: 0 0 10px 0;
	color: #222;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}

.category {
	display: inline-block;
	background: #eef4ff;
	color: #2864d7;
	padding: 5px 10px;
	border-radius: 20px;
	font-size: 13px;
	margin-bottom: 10px;
}

.views {
	color: #777;
	font-size: 14px;
	margin-bottom: 10px;
}

.description {
	color: #666;
	font-size: 14px;
	line-height: 1.5;
	height: 42px;
	overflow: hidden;
}

/* BUTTON */
.product-price {
	font-size: 18px;
	font-weight: 700;
	color: #c0392b;
	margin-top: 12px;
}

.cart-add-form {
	display: flex;
	gap: 8px;
	margin-top: 10px;
}

.cart-add-form input {
	width: 72px;
	padding: 8px;
	border: 1px solid #ddd;
	border-radius: 6px;
}

.cart-add-form button {
	flex: 1;
	border: 0;
	border-radius: 7px;
	background: #16805d;
	color: white;
	font-weight: 700;
	cursor: pointer;
}

.cart-add-form button:disabled {
	background: #8a94a3;
	cursor: not-allowed;
}

.detail-btn {
	display: block;
	text-align: center;
	text-decoration: none;
	background: #2864d7;
	color: white;
	padding: 10px;
	border-radius: 7px;
	margin-top: 15px;
	font-size: 14px;
	transition: background 0.2s;
}

.detail-btn:hover {
	background: #1749a8;
}

/* PAGINATION */
.pagination {
	display: flex;
	justify-content: center;
	align-items: center;
	gap: 8px;
	margin-top: 35px;
	margin-bottom: 30px;
}

.pagination a {
	text-decoration: none;
	padding: 9px 14px;
	border-radius: 7px;
	border: 1px solid #ddd;
	color: #333;
	background: white;
}

.pagination a:hover {
	background: #2864d7;
	color: white;
	border-color: #2864d7;
}

.current-page {
	padding: 9px 14px;
	border-radius: 7px;
	background: #2864d7;
	color: white;
	font-weight: bold;
}

/* RESPONSIVE */
@media ( max-width : 900px) {
	.video-grid {
		grid-template-columns: repeat(2, 1fr);
	}
}

@media ( max-width : 600px) {
	.video-grid {
		grid-template-columns: 1fr;
	}
}
</style>


<div class="video-page">

	<!-- TITLE -->

	<div class="page-title">

		<h1>🎬 DANH SÁCH VIDEO</h1>

		<p>Khám phá những video mới nhất</p>

	</div>


	<!-- VIDEO LIST -->

	<div class="video-grid">

		<c:forEach var="video" items="${videos}">

			<div class="video-card">

				<!-- POSTER -->

				<div class="poster-box">

					<c:choose>

						<c:when test="${not empty video.poster}">

							<img
								src="${pageContext.request.contextPath}/images/${video.poster}"
								alt="${video.title}">

						</c:when>

						<c:otherwise>

							<div class="no-poster">Không có hình ảnh</div>

						</c:otherwise>

					</c:choose>

				</div>


				<!-- CONTENT -->

				<div class="video-content">

					<h3 class="video-title">${video.title}</h3>


					<span class="category"> ${video.categoryName} </span>


					<div class="views">👁 ${video.views} lượt xem</div>


					<div class="description">${video.description}</div>

					<div class="product-price"><c:choose><c:when test="${not empty video.price and video.price gt 0}"><fmt:formatNumber value="${video.price}" type="number" groupingUsed="true" maxFractionDigits="0" /> &#8363;</c:when><c:otherwise>Chưa cập nhật giá</c:otherwise></c:choose></div>

					<c:choose>
						<c:when test="${not empty video.price and video.price gt 0}">
							<form class="cart-add-form" method="post" action="${pageContext.request.contextPath}/cart/add">
								<input type="hidden" name="videoId" value="${video.videoId}">
								<input type="number" name="quantity" value="1" min="1" max="99" aria-label="Số lượng">
								<button type="submit">Thêm vào giỏ</button>
							</form>
						</c:when>
						<c:otherwise><button class="detail-btn" type="button" disabled>Thiết lập giá để mua</button></c:otherwise>
					</c:choose>


					<a class="detail-btn"
						href="${pageContext.request.contextPath}/video/detail?id=${video.videoId}">
						Xem chi tiết → </a>

				</div>

			</div>

		</c:forEach>

	</div>


	<!-- PAGINATION -->

	<div class="pagination">

		<c:if test="${currentPage > 1}">

			<a
				href="${pageContext.request.contextPath}/video?page=${currentPage - 1}">
				← Trước </a>

		</c:if>


		<span class="current-page"> ${currentPage} </span> <span> /
			${totalPages} </span>


		<c:if test="${currentPage < totalPages}">

			<a
				href="${pageContext.request.contextPath}/video?page=${currentPage + 1}">
				Sau → </a>

		</c:if>

	</div>

</div>
