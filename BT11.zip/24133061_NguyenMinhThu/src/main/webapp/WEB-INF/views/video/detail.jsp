<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>${video.title}</title>

<style>
.detail-container {
	max-width: 1000px;
	margin: 40px auto;
	background: white;
	padding: 30px;
	border-radius: 15px;
	box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
}

.detail-poster {
	width: 100%;
	height: 450px;
	object-fit: cover;
	border-radius: 12px;
}

.detail-title {
	font-size: 30px;
	margin-top: 25px;
}

.detail-category {
	display: inline-block;
	padding: 7px 14px;
	background: #e8f0fe;
	color: #3367d6;
	border-radius: 20px;
}

.detail-views {
	color: #777;
	margin: 15px 0;
}

.detail-description {
	font-size: 18px;
	line-height: 1.7;
}

.back {
	display: inline-block;
	margin-top: 25px;
	text-decoration: none;
	color: #3367d6;
}

.detail-price { margin-top: 20px; color: #b42318; font-size: 24px; font-weight: 700; }
.detail-cart-form { display: flex; gap: 10px; margin-top: 14px; }
.detail-cart-form input, .detail-cart-form button { padding: 11px 14px; border-radius: 7px; }
.detail-cart-form input { width: 90px; border: 1px solid #ccd3dc; }
.detail-cart-form button { border: 0; background: #16805d; color: #fff; font-weight: 700; cursor: pointer; }
.detail-cart-form button:disabled { background: #8a94a3; cursor: not-allowed; }
</style>

</head>

<body>

	<div class="detail-container">

		<img class="detail-poster"
			src="${pageContext.request.contextPath}/images/${video.poster}"
			alt="${video.title}">

		<h1 class="detail-title">${video.title}</h1>

		<span class="detail-category"> ${video.categoryName} </span>

		<p class="detail-views">👁 Lượt xem: ${video.views}</p>

		<p class="detail-description">${video.description}</p>

		<p class="detail-price"><c:choose><c:when test="${not empty video.price and video.price gt 0}"><fmt:formatNumber value="${video.price}" type="number" groupingUsed="true" maxFractionDigits="0" /> &#8363;</c:when><c:otherwise>Chưa cập nhật giá</c:otherwise></c:choose></p>

		<c:choose>
			<c:when test="${not empty video.price and video.price gt 0}">
				<form class="detail-cart-form" method="post" action="${pageContext.request.contextPath}/cart/add">
					<input type="hidden" name="videoId" value="${video.videoId}">
					<label>Số lượng <input type="number" name="quantity" value="1" min="1" max="99" required></label>
					<button type="submit">Thêm vào giỏ hàng</button>
				</form>
			</c:when>
			<c:otherwise><button class="detail-cart-form" type="button" disabled>Thiết lập giá để mua</button></c:otherwise>
		</c:choose>

		<a class="back" href="${pageContext.request.contextPath}/home"> ←
			Quay lại trang chủ </a>

	</div>

</body>

</html>
