<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<title>Đăng ký</title>
</head>

<body>

	<h2>ĐĂNG KÝ TÀI KHOẢN</h2>

	<p style="color: red;">${error}</p>

	<form action="${pageContext.request.contextPath}/register"
		method="post">

		<p>
			Username: <input type="text" name="username" required>
		</p>

		<p>
			Password: <input type="password" name="password" required>
		</p>

		<p>
			Họ tên: <input type="text" name="fullname" required>
		</p>

		<p>
			Số điện thoại: <input type="text" name="phone">
		</p>

		<p>
			Email: <input type="email" name="email" required>
		</p>

		<button type="submit">Đăng ký</button>

	</form>

	<p>
		Đã có tài khoản? <a href="${pageContext.request.contextPath}/login">
			Đăng nhập </a>
	</p>

</body>
</html>