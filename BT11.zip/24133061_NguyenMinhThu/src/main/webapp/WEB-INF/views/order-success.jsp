<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<style>
.order-success { max-width: 650px; margin: 55px auto; padding: 36px 24px; text-align: center; background: #fff; border: 1px solid #e5e9ef; border-radius: 14px; color: #20252d; }
.order-success .check { color: #16805d; font-size: 48px; }
.order-success .amount { color: #b42318; font-size: 22px; font-weight: 700; }
.order-success a { display: inline-block; margin-top: 18px; padding: 11px 17px; color: white; background: #1769aa; border-radius: 7px; text-decoration: none; }
</style>

<main class="order-success">
	<div class="check" aria-hidden="true">&#10003;</div>
	<h1>Đặt hàng thành công</h1>
	<p>Mã đơn hàng: <strong>#${receipt.orderId}</strong></p>
	<p>Bạn sẽ thanh toán bằng tiền mặt khi nhận hàng (COD).</p>
	<p class="amount">Tổng tiền: <fmt:formatNumber value="${receipt.totalAmount}" type="number" groupingUsed="true" maxFractionDigits="0"/> &#8363;</p>
	<a href="${pageContext.request.contextPath}/video">Tiếp tục mua hàng</a>
</main>
