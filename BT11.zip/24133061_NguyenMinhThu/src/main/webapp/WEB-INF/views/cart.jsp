<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<style>
.cart-page { max-width: 1050px; margin: 32px auto; padding: 0 18px; color: #20252d; }
.cart-page h1 { margin-bottom: 8px; }
.cart-note { color: #16805d; margin: 12px 0; }
.cart-table-wrap { overflow-x: auto; background: #fff; border: 1px solid #e5e9ef; border-radius: 12px; }
.cart-table { width: 100%; border-collapse: collapse; min-width: 680px; }
.cart-table th, .cart-table td { padding: 14px; text-align: left; border-bottom: 1px solid #edf0f4; }
.cart-table th { background: #f7f9fc; }
.cart-product { display: flex; gap: 12px; align-items: center; min-width: 220px; }
.cart-product img { width: 76px; height: 58px; object-fit: cover; border-radius: 7px; }
.cart-quantity { width: 76px; padding: 8px; border: 1px solid #cfd6df; border-radius: 6px; }
.cart-actions { display: flex; gap: 8px; align-items: center; }
.cart-btn { display: inline-block; border: 0; border-radius: 7px; padding: 10px 15px; background: #1769aa; color: white; text-decoration: none; cursor: pointer; font-weight: 700; }
.cart-btn.secondary { color: #334155; background: #e9eef5; }
.cart-btn.danger { background: #a93232; }
.cart-summary { margin: 20px 0; display: flex; justify-content: flex-end; align-items: center; gap: 20px; font-size: 20px; }
.cart-total { color: #b42318; font-weight: 700; }
.cart-empty { background: #fff; border: 1px solid #e5e9ef; border-radius: 12px; padding: 28px; text-align: center; }
.cart-unavailable { color: #a93232; font-size: 13px; }
@media (max-width: 620px) { .cart-summary { align-items: stretch; flex-direction: column; } }
</style>

<main class="cart-page">
	<h1>Giỏ hàng</h1>
	<p>Kiểm tra sản phẩm và cập nhật số lượng trước khi đặt hàng.</p>
	<c:if test="${not empty cartMessage}"><p class="cart-note" role="status"><c:out value="${cartMessage}"/></p></c:if>

	<c:choose>
		<c:when test="${empty cartItems}">
			<div class="cart-empty">
				<p>Giỏ hàng của bạn đang trống.</p>
				<a class="cart-btn" href="${pageContext.request.contextPath}/video">Tiếp tục mua hàng</a>
			</div>
		</c:when>
		<c:otherwise>
			<div class="cart-table-wrap">
				<table class="cart-table">
					<thead><tr><th>Sản phẩm</th><th>Đơn giá</th><th>Số lượng</th><th>Thành tiền</th><th></th></tr></thead>
					<tbody>
						<c:forEach var="item" items="${cartItems}">
							<tr>
								<td><div class="cart-product"><c:if test="${item.available and not empty item.poster}"><img src="${pageContext.request.contextPath}/images/${item.poster}" alt=""></c:if><strong><c:out value="${item.productName}"/><c:if test="${not item.available}"><br><span class="cart-unavailable">Không thể đặt sản phẩm này</span></c:if></strong></div></td>
								<td><c:choose><c:when test="${item.available}"><fmt:formatNumber value="${item.unitPrice}" type="number" groupingUsed="true" maxFractionDigits="0"/> &#8363;</c:when><c:otherwise>—</c:otherwise></c:choose></td>
								<td>
									<form class="cart-actions" method="post" action="${pageContext.request.contextPath}/cart/update">
										<input type="hidden" name="videoId" value="${item.videoId}">
										<input class="cart-quantity" type="number" name="quantity" value="${item.quantity}" min="1" max="99" required aria-label="Số lượng">
										<button class="cart-btn secondary" type="submit">Cập nhật</button>
									</form>
								</td>
								<td><strong><c:choose><c:when test="${item.available}"><fmt:formatNumber value="${item.lineTotal}" type="number" groupingUsed="true" maxFractionDigits="0"/> &#8363;</c:when><c:otherwise>—</c:otherwise></c:choose></strong></td>
								<td><form method="post" action="${pageContext.request.contextPath}/cart/remove"><input type="hidden" name="videoId" value="${item.videoId}"><button class="cart-btn danger" type="submit">Xóa</button></form></td>
							</tr>
						</c:forEach>
					</tbody>
				</table>
			</div>
			<div class="cart-summary"><span>Tổng cộng: <span class="cart-total"><fmt:formatNumber value="${cartTotal}" type="number" groupingUsed="true" maxFractionDigits="0"/> &#8363;</span></span><c:choose><c:when test="${cartHasUnavailable}"><button class="cart-btn" type="button" disabled title="Xóa sản phẩm không khả dụng trước khi đặt hàng">Tiến hành đặt hàng</button></c:when><c:otherwise><a class="cart-btn" href="${pageContext.request.contextPath}/cart/checkout">Tiến hành đặt hàng</a></c:otherwise></c:choose></div>
		</c:otherwise>
	</c:choose>
</main>
