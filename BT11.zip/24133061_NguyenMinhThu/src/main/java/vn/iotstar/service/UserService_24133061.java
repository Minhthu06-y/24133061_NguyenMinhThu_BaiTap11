package vn.iotstar.service;

import java.util.List;
import vn.iotstar.entity.User_24133061;

public interface UserService_24133061 {

	User_24133061 login(String username, String password);

	void insert(User_24133061 user);

	User_24133061 findByUsername(String username);

	List<User_24133061> findAll();

	List<User_24133061> findPage(int page, int pageSize);

	void update(User_24133061 user);

	void delete(String username);

	int count();
}