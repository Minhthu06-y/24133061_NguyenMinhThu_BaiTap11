package vn.iotstar.service.impl;

import java.util.List;

import vn.iotstar.dao.VideoDAO_24133061;
import vn.iotstar.dao.impl.VideoDAOImpl_24133061;
import vn.iotstar.entity.Video_24133061;
import vn.iotstar.service.VideoService_24133061;

public class VideoServiceImpl_24133061 implements VideoService_24133061 {

	private VideoDAO_24133061 videoDAO;

	public VideoServiceImpl_24133061() {
		videoDAO = new VideoDAOImpl_24133061();
	}

	@Override
	public List<Video_24133061> findAll() {
		return videoDAO.findAll();
	}

	@Override
	public List<Video_24133061> findPage(int page, int pageSize) {

		return videoDAO.findPage(page, pageSize);
	}

	@Override
	public Video_24133061 findById(String videoId) {
		return videoDAO.findById(videoId);
	}

	@Override
	public int count() {
		return videoDAO.count();
	}
}