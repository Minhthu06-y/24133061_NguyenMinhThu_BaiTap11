package vn.iotstar.service.impl;

import java.util.List;

import vn.iotstar.dao.UserDAO_24133061;
import vn.iotstar.dao.impl.UserDAOImpl_24133061;
import vn.iotstar.entity.User_24133061;
import vn.iotstar.service.UserService_24133061;

public class UserServiceImpl_24133061 implements UserService_24133061 {

	private UserDAO_24133061 userDAO;

	public UserServiceImpl_24133061() {
		userDAO = new UserDAOImpl_24133061();
	}

	@Override
	public User_24133061 login(String username, String password) {
		return userDAO.login(username, password);
	}

	@Override
	public void insert(User_24133061 user) {
		userDAO.insert(user);
	}

	@Override
	public User_24133061 findByUsername(String username) {
		return userDAO.findByUsername(username);
	}

	@Override
	public List<User_24133061> findAll() {
		return userDAO.findAll();
	}

	@Override
	public List<User_24133061> findPage(int page, int pageSize) {
		return userDAO.findPage(page, pageSize);
	}

	@Override
	public void update(User_24133061 user) {
		userDAO.update(user);
	}

	@Override
	public void delete(String username) {
		userDAO.delete(username);
	}

	@Override
	public int count() {
		return userDAO.count();
	}
}