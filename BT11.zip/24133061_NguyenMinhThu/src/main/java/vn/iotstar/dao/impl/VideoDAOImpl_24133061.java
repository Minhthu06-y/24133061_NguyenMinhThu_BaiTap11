package vn.iotstar.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import vn.iotstar.dao.VideoDAO_24133061;
import vn.iotstar.entity.Video_24133061;
import vn.iotstar.util.DBConnection_24133061;

public class VideoDAOImpl_24133061 implements VideoDAO_24133061 {

	@Override
	public List<Video_24133061> findAll() {

		List<Video_24133061> list = new ArrayList<>();

		String sql = """
				SELECT v.*, c.Categoryname
				FROM Videos v
				LEFT JOIN Category c
				    ON v.CategoryId = c.CategoryId
				WHERE v.Active = 1
				ORDER BY v.VideoId
				""";

		try (Connection conn = DBConnection_24133061.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {

			while (rs.next()) {
				list.add(mapResultSet(rs));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public List<Video_24133061> findPage(int page, int pageSize) {

		List<Video_24133061> list = new ArrayList<>();

		String sql = """
				SELECT v.*, c.Categoryname
				FROM Videos v
				LEFT JOIN Category c
				    ON v.CategoryId = c.CategoryId
				WHERE v.Active = 1
				ORDER BY v.VideoId
				OFFSET ? ROWS
				FETCH NEXT ? ROWS ONLY
				""";

		try (Connection conn = DBConnection_24133061.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {

			int offset = (page - 1) * pageSize;

			ps.setInt(1, offset);
			ps.setInt(2, pageSize);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				list.add(mapResultSet(rs));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public Video_24133061 findById(String videoId) {

		String sql = """
				SELECT v.*, c.Categoryname
				FROM Videos v
				LEFT JOIN Category c
				    ON v.CategoryId = c.CategoryId
				WHERE v.VideoId = ?
				  AND v.Active = 1
				""";

		try (Connection conn = DBConnection_24133061.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, videoId);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				return mapResultSet(rs);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public int count() {

		String sql = """
				SELECT COUNT(*)
				FROM Videos
				WHERE Active = 1
				""";

		try (Connection conn = DBConnection_24133061.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {

			if (rs.next()) {
				return rs.getInt(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return 0;
	}

	private Video_24133061 mapResultSet(ResultSet rs) throws Exception {

		Video_24133061 video = new Video_24133061();

		video.setVideoId(rs.getString("VideoId"));
		video.setTitle(rs.getString("Title"));
		video.setPoster(rs.getString("Poster"));
		video.setViews(rs.getInt("Views"));
		video.setDescription(rs.getString("Description"));
		video.setActive(rs.getBoolean("Active"));
		video.setCategoryId(rs.getInt("CategoryId"));
		video.setCategoryName(rs.getString("Categoryname"));
		try {
			video.setPrice(rs.getBigDecimal("Price"));
		} catch (java.sql.SQLException missingPriceColumn) {
			// Keep the catalog readable before the optional cart schema migration is applied.
			video.setPrice(null);
		}

		return video;
	}
}
