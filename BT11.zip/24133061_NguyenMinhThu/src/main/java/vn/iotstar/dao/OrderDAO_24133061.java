package vn.iotstar.dao;

import java.sql.SQLException;
import java.util.Map;

import vn.iotstar.entity.OrderReceipt_24133061;

public interface OrderDAO_24133061 {
	OrderReceipt_24133061 createCodOrder(String customerName, String phone, String address, String note,
			Map<String, Integer> quantities) throws SQLException;
}
