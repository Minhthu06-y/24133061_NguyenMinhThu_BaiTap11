package vn.iotstar.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import vn.iotstar.dao.UserDAO_24133061;
import vn.iotstar.entity.User_24133061;
import vn.iotstar.util.DBConnection_24133061;

public class UserDAOImpl_24133061 implements UserDAO_24133061 {

	@Override
	public void insert(User_24133061 user) {

		String sql = "INSERT INTO Users " + "(Username, Password, Phone, Fullname, Email, Admin, Active, Images) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

		try (Connection conn = DBConnection_24133061.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getPhone());
			ps.setString(4, user.getFullname());
			ps.setString(5, user.getEmail());
			ps.setBoolean(6, user.isAdmin());
			ps.setBoolean(7, user.isActive());
			ps.setString(8, user.getImages());

			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public User_24133061 findByUsername(String username) {

		String sql = "SELECT * FROM Users WHERE Username = ?";

		try (Connection conn = DBConnection_24133061.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, username);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				return mapResultSet(rs);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public User_24133061 login(String username, String password) {

		String sql = "SELECT * FROM Users " + "WHERE Username = ? " + "AND Password = ? " + "AND Active = 1";

		try (Connection conn = DBConnection_24133061.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, username);
			ps.setString(2, password);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				return mapResultSet(rs);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<User_24133061> findAll() {

		List<User_24133061> list = new ArrayList<>();

		String sql = "SELECT * FROM Users";

		try (Connection conn = DBConnection_24133061.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {

			while (rs.next()) {
				list.add(mapResultSet(rs));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public List<User_24133061> findPage(int page, int pageSize) {

		List<User_24133061> list = new ArrayList<>();

		String sql = "SELECT * FROM Users " + "ORDER BY Username " + "OFFSET ? ROWS " + "FETCH NEXT ? ROWS ONLY";

		try (Connection conn = DBConnection_24133061.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {

			int offset = (page - 1) * pageSize;

			ps.setInt(1, offset);
			ps.setInt(2, pageSize);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				list.add(mapResultSet(rs));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public void update(User_24133061 user) {

		String sql = "UPDATE Users SET " + "Password = ?, " + "Phone = ?, " + "Fullname = ?, " + "Email = ?, "
				+ "Admin = ?, " + "Active = ?, " + "Images = ? " + "WHERE Username = ?";

		try (Connection conn = DBConnection_24133061.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, user.getPassword());
			ps.setString(2, user.getPhone());
			ps.setString(3, user.getFullname());
			ps.setString(4, user.getEmail());
			ps.setBoolean(5, user.isAdmin());
			ps.setBoolean(6, user.isActive());
			ps.setString(7, user.getImages());
			ps.setString(8, user.getUsername());

			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void delete(String username) {

		String sql = "DELETE FROM Users WHERE Username = ?";

		try (Connection conn = DBConnection_24133061.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, username);
			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int count() {

		String sql = "SELECT COUNT(*) FROM Users";

		try (Connection conn = DBConnection_24133061.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {

			if (rs.next()) {
				return rs.getInt(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return 0;
	}

	private User_24133061 mapResultSet(ResultSet rs) throws Exception {

		User_24133061 user = new User_24133061();

		user.setUsername(rs.getString("Username"));
		user.setPassword(rs.getString("Password"));
		user.setPhone(rs.getString("Phone"));
		user.setFullname(rs.getString("Fullname"));
		user.setEmail(rs.getString("Email"));
		user.setAdmin(rs.getBoolean("Admin"));
		user.setActive(rs.getBoolean("Active"));
		user.setImages(rs.getString("Images"));

		return user;
	}
}