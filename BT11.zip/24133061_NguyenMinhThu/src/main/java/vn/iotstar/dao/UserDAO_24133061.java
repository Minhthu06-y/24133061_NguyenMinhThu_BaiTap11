package vn.iotstar.dao;

import java.util.List;
import vn.iotstar.entity.User_24133061;

public interface UserDAO_24133061 {

	void insert(User_24133061 user);

	User_24133061 findByUsername(String username);

	User_24133061 login(String username, String password);

	List<User_24133061> findAll();

	List<User_24133061> findPage(int page, int pageSize);

	void update(User_24133061 user);

	void delete(String username);

	int count();
}