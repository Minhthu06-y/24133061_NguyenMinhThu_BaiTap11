package vn.iotstar.dao.impl;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import vn.iotstar.dao.OrderDAO_24133061;
import vn.iotstar.entity.OrderReceipt_24133061;
import vn.iotstar.util.DBConnection_24133061;

public class OrderDAOImpl_24133061 implements OrderDAO_24133061 {

	private static final int MAX_QUANTITY = 99;

	private static class OrderLine {
		private final String videoId;
		private final String title;
		private final int quantity;
		private final BigDecimal unitPrice;

		private OrderLine(String videoId, String title, int quantity, BigDecimal unitPrice) {
			this.videoId = videoId;
			this.title = title;
			this.quantity = quantity;
			this.unitPrice = unitPrice;
		}

		private BigDecimal getLineTotal() {
			return unitPrice.multiply(BigDecimal.valueOf(quantity));
		}
	}

	@Override
	public OrderReceipt_24133061 createCodOrder(String customerName, String phone, String address, String note,
			Map<String, Integer> quantities) throws SQLException {
		if (quantities == null || quantities.isEmpty()) {
			throw new SQLException("Giỏ hàng đang trống.");
		}

		try (Connection connection = DBConnection_24133061.getConnection()) {
			connection.setAutoCommit(false);
			try {
				List<OrderLine> lines = loadCurrentLines(connection, quantities);
				BigDecimal total = lines.stream().map(OrderLine::getLineTotal).reduce(BigDecimal.ZERO, BigDecimal::add);
				long orderId = insertOrder(connection, customerName, phone, address, note, total);
				insertOrderLines(connection, orderId, lines);
				connection.commit();
				return new OrderReceipt_24133061(orderId, total);
			} catch (SQLException | RuntimeException e) {
				try {
					connection.rollback();
				} catch (SQLException rollbackError) {
					e.addSuppressed(rollbackError);
				}
				throw e;
			}
		}
	}

	private List<OrderLine> loadCurrentLines(Connection connection, Map<String, Integer> quantities) throws SQLException {
		String sql = "SELECT Title, Price FROM Videos WHERE VideoId = ? AND Active = 1";
		List<OrderLine> lines = new ArrayList<>();
		try (PreparedStatement statement = connection.prepareStatement(sql)) {
			for (Map.Entry<String, Integer> item : quantities.entrySet()) {
				Integer quantity = item.getValue();
				if (item.getKey() == null || item.getKey().isBlank() || quantity == null || quantity < 1
						|| quantity > MAX_QUANTITY) {
					throw new SQLException("Số lượng sản phẩm không hợp lệ.");
				}
				statement.setString(1, item.getKey());
				try (ResultSet result = statement.executeQuery()) {
					if (!result.next()) {
						throw new SQLException("Có sản phẩm không còn khả dụng. Vui lòng kiểm tra lại giỏ hàng.");
					}
					BigDecimal price = result.getBigDecimal("Price");
					if (price == null || price.signum() <= 0) {
						throw new SQLException("Sản phẩm chưa được thiết lập giá.");
					}
					lines.add(new OrderLine(item.getKey(), result.getString("Title"), quantity, price));
				}
			}
		}
		return lines;
	}

	private long insertOrder(Connection connection, String customerName, String phone, String address, String note,
			BigDecimal total) throws SQLException {
		String sql = "INSERT INTO Orders (CustomerName, Phone, ShippingAddress, Note, TotalAmount, PaymentMethod, OrderStatus) "
				+ "VALUES (?, ?, ?, ?, ?, N'COD', N'Chờ xác nhận')";
		try (PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
			statement.setNString(1, customerName);
			statement.setString(2, phone);
			statement.setNString(3, address);
			statement.setNString(4, note == null ? "" : note);
			statement.setBigDecimal(5, total);
			statement.executeUpdate();
			try (ResultSet keys = statement.getGeneratedKeys()) {
				if (keys.next()) {
					return keys.getLong(1);
				}
			}
		}
		throw new SQLException("Không lấy được mã đơn hàng.");
	}

	private void insertOrderLines(Connection connection, long orderId, List<OrderLine> lines) throws SQLException {
		String sql = "INSERT INTO OrderItems (OrderId, VideoId, ProductName, Quantity, UnitPrice, LineTotal) "
				+ "VALUES (?, ?, ?, ?, ?, ?)";
		try (PreparedStatement statement = connection.prepareStatement(sql)) {
			for (OrderLine line : lines) {
				statement.setLong(1, orderId);
				statement.setNString(2, line.videoId);
				statement.setNString(3, line.title);
				statement.setInt(4, line.quantity);
				statement.setBigDecimal(5, line.unitPrice);
				statement.setBigDecimal(6, line.getLineTotal());
				statement.addBatch();
			}
			statement.executeBatch();
		}
	}
}
