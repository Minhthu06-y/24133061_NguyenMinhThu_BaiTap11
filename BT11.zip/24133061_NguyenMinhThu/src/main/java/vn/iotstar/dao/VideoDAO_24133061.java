package vn.iotstar.dao;

import java.util.List;

import vn.iotstar.entity.Video_24133061;

public interface VideoDAO_24133061 {

	List<Video_24133061> findAll();

	List<Video_24133061> findPage(int page, int pageSize);

	Video_24133061 findById(String videoId);

	int count();
}