package vn.iotstar.controllers;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import vn.iotstar.entity.Video_24133061;
import vn.iotstar.service.VideoService_24133061;
import vn.iotstar.service.impl.VideoServiceImpl_24133061;

@WebServlet("/home")
public class HomeController_24133061 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private VideoService_24133061 service = new VideoServiceImpl_24133061();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<Video_24133061> videos = service.findAll();

		System.out.println("========== HOME DATABASE ==========");

		System.out.println("SO VIDEO: " + videos.size());

		for (Video_24133061 video : videos) {

			System.out.println(video.getVideoId() + " - " + video.getTitle());
		}

		request.setAttribute("videos", videos);

		request.getRequestDispatcher("/WEB-INF/views/home.jsp").forward(request, response);
	}
}