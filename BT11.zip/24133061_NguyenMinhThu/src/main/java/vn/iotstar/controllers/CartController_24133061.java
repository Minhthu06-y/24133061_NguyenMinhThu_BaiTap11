package vn.iotstar.controllers;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import vn.iotstar.dao.OrderDAO_24133061;
import vn.iotstar.dao.impl.OrderDAOImpl_24133061;
import vn.iotstar.entity.CartItem_24133061;
import vn.iotstar.entity.OrderReceipt_24133061;
import vn.iotstar.entity.User_24133061;
import vn.iotstar.entity.Video_24133061;
import vn.iotstar.service.VideoService_24133061;
import vn.iotstar.service.impl.VideoServiceImpl_24133061;

@WebServlet("/cart/*")
public class CartController_24133061 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int MAX_QUANTITY = 99;
	private static final Logger LOGGER = Logger.getLogger(CartController_24133061.class.getName());
	private final VideoService_24133061 videoService = new VideoServiceImpl_24133061();
	private final OrderDAO_24133061 orderDAO = new OrderDAOImpl_24133061();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		switch (getAction(request)) {
		case "/checkout" -> showCheckout(request, response);
		case "/success" -> showSuccess(request, response);
		default -> showCart(request, response);
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		switch (getAction(request)) {
		case "/add" -> addItem(request, response);
		case "/update" -> updateItem(request, response);
		case "/remove" -> removeItem(request, response);
		case "/checkout" -> checkout(request, response);
		default -> response.sendError(HttpServletResponse.SC_NOT_FOUND);
		}
	}

	private String getAction(HttpServletRequest request) {
		String path = request.getPathInfo();
		return path == null || path.isBlank() ? "/" : path;
	}

	@SuppressWarnings("unchecked")
	private Map<String, Integer> getCart(HttpSession session) {
		Object value = session.getAttribute("cartItems");
		if (value instanceof Map<?, ?>) {
			return (Map<String, Integer>) value;
		}
		Map<String, Integer> cart = new LinkedHashMap<>();
		session.setAttribute("cartItems", cart);
		return cart;
	}

	private void addItem(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String videoId = request.getParameter("videoId");
		int quantity = parseQuantity(request.getParameter("quantity"), 1);
		Video_24133061 video = videoId == null ? null : videoService.findById(videoId.trim());
		if (video == null || video.getPrice() == null || video.getPrice().signum() <= 0) {
			flash(request.getSession(), "Sản phẩm không tồn tại hoặc chưa được thiết lập giá.");
			redirect(request, response, "/cart");
			return;
		}
		HttpSession session = request.getSession();
		Map<String, Integer> cart = getCart(session);
		int current = cart.getOrDefault(videoId.trim(), 0);
		int updated = Math.min(MAX_QUANTITY, current + quantity);
		cart.put(videoId.trim(), updated);
		flash(session, updated < current + quantity ? "Số lượng đã được giới hạn ở 99 sản phẩm." : "Đã thêm sản phẩm vào giỏ hàng.");
		redirect(request, response, "/cart");
	}

	private void updateItem(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String videoId = request.getParameter("videoId");
		Integer quantity = tryParseInteger(request.getParameter("quantity"));
		Map<String, Integer> cart = getCart(request.getSession());
		if (videoId == null || !cart.containsKey(videoId) || quantity == null || quantity < 1
				|| quantity > MAX_QUANTITY) {
			flash(request.getSession(), "Số lượng phải từ 1 đến 99.");
		} else {
			cart.put(videoId, quantity);
			flash(request.getSession(), "Đã cập nhật giỏ hàng.");
		}
		redirect(request, response, "/cart");
	}

	private void removeItem(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String videoId = request.getParameter("videoId");
		if (videoId != null) {
			getCart(request.getSession()).remove(videoId);
		}
		flash(request.getSession(), "Đã xóa sản phẩm khỏi giỏ hàng.");
		redirect(request, response, "/cart");
	}

	private void showCart(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<CartItem_24133061> items = loadItems(request);
		if (items == null) {
			return;
		}
		request.setAttribute("cartItems", items);
		request.setAttribute("cartTotal", calculateTotal(items));
		String message = consumeFlash(request.getSession(false));
		if (message != null) {
			request.setAttribute("cartMessage", message);
		}
		request.getRequestDispatcher("/WEB-INF/views/cart.jsp").forward(request, response);
	}

	private void showCheckout(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<CartItem_24133061> items = loadItems(request);
		if (items == null) {
			return;
		}
		if (items.isEmpty()) {
			flash(request.getSession(), "Giỏ hàng đang trống.");
			redirect(request, response, "/cart");
			return;
		}
		if (Boolean.TRUE.equals(request.getAttribute("cartHasUnavailable"))) {
			flash(request.getSession(), "Vui lòng xóa sản phẩm không khả dụng khỏi giỏ hàng trước khi đặt hàng.");
			redirect(request, response, "/cart");
			return;
		}
		request.setAttribute("cartItems", items);
		request.setAttribute("cartTotal", calculateTotal(items));
		String message = consumeFlash(request.getSession(false));
		if (message != null) {
			request.setAttribute("checkoutMessage", message);
		}
		prefillCustomer(request);
		request.getRequestDispatcher("/WEB-INF/views/checkout.jsp").forward(request, response);
	}

	private void checkout(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = trim(request.getParameter("customerName"));
		String phone = trim(request.getParameter("phone"));
		String address = trim(request.getParameter("address"));
		String note = trim(request.getParameter("note"));
		String error = validateCheckout(name, phone, address, note);
		if (error != null) {
			showCheckoutError(request, response, error, name, phone, address, note);
			return;
		}

		HttpSession session = request.getSession();
		Map<String, Integer> cart = getCart(session);
		if (cart.isEmpty()) {
			flash(session, "Giỏ hàng đang trống.");
			redirect(request, response, "/cart");
			return;
		}
		try {
			OrderReceipt_24133061 receipt = orderDAO.createCodOrder(name, phone, address, note,
					new LinkedHashMap<>(cart));
			cart.clear();
			session.setAttribute("cartCount", 0);
			session.setAttribute("lastOrderReceipt", receipt);
			response.sendRedirect(request.getContextPath() + "/cart/success?id=" + receipt.getOrderId());
		} catch (SQLException e) {
			LOGGER.log(Level.SEVERE, "Could not save COD order", e);
			String safeMessage = e.getMessage() != null && e.getMessage().startsWith("Có sản phẩm")
					? e.getMessage() : "Chưa thể tạo đơn hàng lúc này. Vui lòng thử lại.";
			showCheckoutError(request, response, safeMessage, name, phone, address, note);
		}
	}

	private void showCheckoutError(HttpServletRequest request, HttpServletResponse response, String error,
			String name, String phone, String address, String note) throws ServletException, IOException {
		List<CartItem_24133061> items = loadItems(request);
		if (items == null) {
			return;
		}
		if (items.isEmpty()) {
			flash(request.getSession(), "Giỏ hàng đang trống.");
			redirect(request, response, "/cart");
			return;
		}
		if (Boolean.TRUE.equals(request.getAttribute("cartHasUnavailable"))) {
			flash(request.getSession(), "Vui lòng xóa sản phẩm không khả dụng khỏi giỏ hàng trước khi đặt hàng.");
			redirect(request, response, "/cart");
			return;
		}
		request.setAttribute("cartItems", items);
		request.setAttribute("cartTotal", calculateTotal(items));
		request.setAttribute("checkoutMessage", error);
		request.setAttribute("checkoutName", name);
		request.setAttribute("checkoutPhone", phone);
		request.setAttribute("checkoutAddress", address);
		request.setAttribute("checkoutNote", note);
		request.getRequestDispatcher("/WEB-INF/views/checkout.jsp").forward(request, response);
	}

	private void showSuccess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		Object value = session == null ? null : session.getAttribute("lastOrderReceipt");
		String id = request.getParameter("id");
		if (!(value instanceof OrderReceipt_24133061 receipt) || id == null
				|| !id.equals(Long.toString(receipt.getOrderId()))) {
			response.sendError(HttpServletResponse.SC_NOT_FOUND);
			return;
		}
		request.setAttribute("receipt", receipt);
		request.getRequestDispatcher("/WEB-INF/views/order-success.jsp").forward(request, response);
	}

	private List<CartItem_24133061> loadItems(HttpServletRequest request)
			throws ServletException, IOException {
		Map<String, Integer> cart = getCart(request.getSession());
		List<CartItem_24133061> items = new ArrayList<>();
		boolean hasUnavailable = false;
		int count = 0;
		for (Map.Entry<String, Integer> entry : cart.entrySet()) {
			Video_24133061 video = videoService.findById(entry.getKey());
			if (video == null || video.getPrice() == null || video.getPrice().signum() <= 0) {
				hasUnavailable = true;
			}
			int quantity = entry.getValue() == null ? 1 : Math.max(1, Math.min(MAX_QUANTITY, entry.getValue()));
			entry.setValue(quantity);
			count += quantity;
			items.add(new CartItem_24133061(entry.getKey(), video, quantity));
		}
		request.getSession().setAttribute("cartCount", count);
		if (hasUnavailable) {
			request.setAttribute("cartHasUnavailable", true);
			flash(request.getSession(), "Một số sản phẩm không còn khả dụng hoặc chưa có giá. Hãy xóa chúng khỏi giỏ hàng.");
		}
		return items;
	}

	private BigDecimal calculateTotal(List<CartItem_24133061> items) {
		return items.stream().map(CartItem_24133061::getLineTotal).reduce(BigDecimal.ZERO, BigDecimal::add);
	}

	private String validateCheckout(String name, String phone, String address, String note) {
		if (name.length() < 2 || name.length() > 100) {
			return "Vui lòng nhập họ tên từ 2 đến 100 ký tự.";
		}
		long digits = phone.chars().filter(Character::isDigit).count();
		if (phone.length() > 20 || digits < 8 || !phone.matches("[0-9+(). \\-]+")) {
			return "Số điện thoại không hợp lệ.";
		}
		if (address.length() < 5 || address.length() > 500) {
			return "Vui lòng nhập địa chỉ nhận hàng từ 5 đến 500 ký tự.";
		}
		if (note.length() > 1000) {
			return "Ghi chú không được vượt quá 1000 ký tự.";
		}
		return null;
	}

	private void prefillCustomer(HttpServletRequest request) {
		if (request.getAttribute("checkoutName") != null) {
			return;
		}
		Object value = request.getSession().getAttribute("account");
		if (value instanceof User_24133061 user) {
			request.setAttribute("checkoutName", user.getFullname());
			request.setAttribute("checkoutPhone", user.getPhone());
		}
	}

	private String trim(String value) {
		return value == null ? "" : value.trim();
	}

	private int parseQuantity(String value, int fallback) {
		Integer parsed = tryParseInteger(value);
		return parsed == null || parsed < 1 ? fallback : Math.min(parsed, MAX_QUANTITY);
	}

	private Integer tryParseInteger(String value) {
		try {
			return Integer.valueOf(value);
		} catch (Exception e) {
			return null;
		}
	}

	private void flash(HttpSession session, String message) {
		session.setAttribute("cartFlash", message);
	}

	private String consumeFlash(HttpSession session) {
		if (session == null) {
			return null;
		}
		Object message = session.getAttribute("cartFlash");
		session.removeAttribute("cartFlash");
		return message == null ? null : message.toString();
	}

	private void redirect(HttpServletRequest request, HttpServletResponse response, String path) throws IOException {
		response.sendRedirect(request.getContextPath() + path);
	}
}
