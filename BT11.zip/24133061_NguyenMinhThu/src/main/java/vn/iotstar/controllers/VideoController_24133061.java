package vn.iotstar.controllers;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import vn.iotstar.entity.Video_24133061;
import vn.iotstar.service.VideoService_24133061;
import vn.iotstar.service.impl.VideoServiceImpl_24133061;

@WebServlet({ "/video", "/video/detail" })
public class VideoController_24133061 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private VideoService_24133061 service = new VideoServiceImpl_24133061();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String uri = req.getRequestURI();

		// ==========================================
		// CHI TIẾT VIDEO
		// /video/detail?id=VID002
		// ==========================================

		if (uri.endsWith("/video/detail")) {

			String id = req.getParameter("id");

			System.out.println("VIDEO DETAIL ID = [" + id + "]");

			if (id == null || id.trim().isEmpty()) {

				resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Thiếu video id");

				return;
			}

			Video_24133061 video = service.findById(id);

			if (video == null) {

				resp.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy video: " + id);

				return;
			}

			req.setAttribute("video", video);

			req.getRequestDispatcher("/WEB-INF/views/video/detail.jsp").forward(req, resp);

			return;
		}

		// ==========================================
		// DANH SÁCH VIDEO
		// /video
		// ==========================================

		int page = 1;

		String pageParam = req.getParameter("page");

		if (pageParam != null) {

			try {

				page = Integer.parseInt(pageParam);

			} catch (Exception e) {

				page = 1;
			}
		}

		int pageSize = 3;

		int totalVideos = service.count();

		int totalPages = (int) Math.ceil((double) totalVideos / pageSize);

		if (totalPages == 0) {
			totalPages = 1;
		}

		if (page < 1) {
			page = 1;
		}

		if (page > totalPages) {
			page = totalPages;
		}

		req.setAttribute("videos", service.findPage(page, pageSize));

		req.setAttribute("currentPage", page);

		req.setAttribute("totalPages", totalPages);

		req.getRequestDispatcher("/WEB-INF/views/video/video.jsp").forward(req, resp);
	}
}