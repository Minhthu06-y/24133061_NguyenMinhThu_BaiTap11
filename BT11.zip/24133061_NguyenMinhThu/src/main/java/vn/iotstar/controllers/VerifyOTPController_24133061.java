package vn.iotstar.controllers;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import vn.iotstar.entity.User_24133061;
import vn.iotstar.service.UserService_24133061;
import vn.iotstar.service.impl.UserServiceImpl_24133061;

@WebServlet("/verify-otp")
public class VerifyOTPController_24133061 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private UserService_24133061 service = new UserServiceImpl_24133061();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.getRequestDispatcher("/WEB-INF/views/verify-otp.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");

		String otpInput = req.getParameter("otp");

		HttpSession session = req.getSession(false);

		if (session == null) {

			resp.sendRedirect(req.getContextPath() + "/register");

			return;
		}

		String otp = (String) session.getAttribute("registerOTP");

		User_24133061 user = (User_24133061) session.getAttribute("registerUser");

		// Kiểm tra OTP
		if (otp != null && otp.equals(otpInput) && user != null) {

			service.insert(user);

			// Xóa dữ liệu đăng ký khỏi session
			session.removeAttribute("registerOTP");
			session.removeAttribute("registerUser");

			// Đăng ký thành công
			resp.sendRedirect(req.getContextPath() + "/login");

		} else {

			req.setAttribute("error", "OTP không đúng!");

			req.getRequestDispatcher("/WEB-INF/views/verify-otp.jsp").forward(req, resp);
		}
	}
}