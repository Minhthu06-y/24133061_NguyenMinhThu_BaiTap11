package vn.iotstar.controllers;

import java.io.IOException;
import java.util.Random;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import vn.iotstar.entity.User_24133061;
import vn.iotstar.service.UserService_24133061;
import vn.iotstar.service.impl.UserServiceImpl_24133061;
import vn.iotstar.util.EmailUtil_24133061;

@WebServlet("/register")
public class RegisterController_24133061 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private UserService_24133061 service = new UserServiceImpl_24133061();

	// =========================
	// HIỆN FORM ĐĂNG KÝ
	// =========================

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req, resp);
	}

	// =========================
	// GỬI OTP
	// =========================

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");

		String username = req.getParameter("username");

		String password = req.getParameter("password");

		String phone = req.getParameter("phone");

		String fullname = req.getParameter("fullname");

		String email = req.getParameter("email");

		// Kiểm tra username tồn tại
		if (service.findByUsername(username) != null) {

			req.setAttribute("error", "Username đã tồn tại!");

			req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req, resp);

			return;
		}

		// Tạo OTP 6 số
		String otp = String.format("%06d", new Random().nextInt(1000000));

		// Lưu thông tin đăng ký vào Session
		HttpSession session = req.getSession();

		User_24133061 user = new User_24133061();

		user.setUsername(username);
		user.setPassword(password);
		user.setPhone(phone);
		user.setFullname(fullname);
		user.setEmail(email);
		user.setAdmin(false);
		user.setActive(true);
		user.setImages(null);

		session.setAttribute("registerUser", user);

		session.setAttribute("registerOTP", otp);

		// Gửi OTP
		try {

			EmailUtil_24133061.sendOTP(email, otp);

			resp.sendRedirect(req.getContextPath() + "/verify-otp");

		} catch (Exception e) {

			e.printStackTrace();

			req.setAttribute("error", "Không gửi được OTP. Kiểm tra email!");

			req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req, resp);
		}
	}
}