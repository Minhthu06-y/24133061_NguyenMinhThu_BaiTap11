package vn.iotstar.controllers;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import vn.iotstar.entity.User_24133061;
import vn.iotstar.service.UserService_24133061;
import vn.iotstar.service.impl.UserServiceImpl_24133061;

@WebServlet("/login")
public class LoginController_24133061 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private UserService_24133061 service = new UserServiceImpl_24133061();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String username = req.getParameter("username");
		String password = req.getParameter("password");

		User_24133061 user = service.login(username, password);

		if (user != null) {

			HttpSession session = req.getSession();
			session.setAttribute("account", user);

			if (user.isAdmin()) {
				resp.sendRedirect(req.getContextPath() + "/admin/home");
			} else {
				resp.sendRedirect(req.getContextPath() + "/home");
			}

		} else {

			req.setAttribute("error", "Sai tài khoản hoặc mật khẩu!");

			req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, resp);
		}
	}
}