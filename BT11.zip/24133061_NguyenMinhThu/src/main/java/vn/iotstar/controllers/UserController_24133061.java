package vn.iotstar.controllers;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import vn.iotstar.entity.User_24133061;
import vn.iotstar.service.UserService_24133061;
import vn.iotstar.service.impl.UserServiceImpl_24133061;

@WebServlet("/users")
public class UserController_24133061 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private UserService_24133061 service =
            new UserServiceImpl_24133061();

    // =========================
    // KIỂM TRA ADMIN
    // =========================
    private boolean isAdmin(HttpServletRequest req) {

        HttpSession session = req.getSession(false);

        if (session == null) {
            return false;
        }

        Object obj = session.getAttribute("account");

        if (!(obj instanceof User_24133061)) {
            return false;
        }

        User_24133061 user = (User_24133061) obj;

        return user.isAdmin();
    }

    // =========================
    // GET
    // =========================
    @Override
    protected void doGet(HttpServletRequest req,
            HttpServletResponse resp)
            throws ServletException, IOException {

        // Chỉ Admin được vào
        if (!isAdmin(req)) {
            resp.sendRedirect(
                    req.getContextPath() + "/login");
            return;
        }

        String action = req.getParameter("action");

        if (action == null) {
            action = "list";
        }

        // =========================
        // DELETE
        // =========================
        if ("delete".equals(action)) {

            String username =
                    req.getParameter("username");

            if (username != null && !username.isEmpty()) {
                service.delete(username);
            }

            resp.sendRedirect(
                    req.getContextPath() + "/users");

            return;
        }

        // =========================
        // EDIT
        // =========================
        if ("edit".equals(action)) {

            String username =
                    req.getParameter("username");

            User_24133061 user =
                    service.findByUsername(username);

            req.setAttribute("user", user);

            req.getRequestDispatcher(
                    "/WEB-INF/views/user/user-form.jsp")
               .forward(req, resp);

            return;
        }

        // =========================
        // ADD
        // =========================
        if ("add".equals(action)) {

            req.setAttribute("user", null);

            req.getRequestDispatcher(
                    "/WEB-INF/views/user/user-form.jsp")
               .forward(req, resp);

            return;
        }

        // =========================
        // LIST + PAGINATION
        // =========================

        int page = 1;

        String pageParam =
                req.getParameter("page");

        if (pageParam != null) {
            try {
                page = Integer.parseInt(pageParam);
            } catch (NumberFormatException e) {
                page = 1;
            }
        }

        int pageSize = 6;

        int totalUsers = service.count();

        int totalPages =
                (int) Math.ceil(
                        (double) totalUsers / pageSize);

        if (totalPages == 0) {
            totalPages = 1;
        }

        if (page < 1) {
            page = 1;
        }

        if (page > totalPages) {
            page = totalPages;
        }

        req.setAttribute(
                "users",
                service.findPage(page, pageSize));

        req.setAttribute(
                "currentPage",
                page);

        req.setAttribute(
                "totalPages",
                totalPages);

        req.getRequestDispatcher(
                "/WEB-INF/views/user/users.jsp")
           .forward(req, resp);
    }

    // =========================
    // POST
    // =========================
    @Override
    protected void doPost(HttpServletRequest req,
            HttpServletResponse resp)
            throws ServletException, IOException {

        // Chỉ Admin được thêm/sửa
        if (!isAdmin(req)) {
            resp.sendRedirect(
                    req.getContextPath() + "/login");
            return;
        }

        req.setCharacterEncoding("UTF-8");

        String username =
                req.getParameter("username");

        String password =
                req.getParameter("password");

        String phone =
                req.getParameter("phone");

        String fullname =
                req.getParameter("fullname");

        String email =
                req.getParameter("email");

        boolean admin =
                "1".equals(req.getParameter("admin"));

        boolean active =
                "1".equals(req.getParameter("active"));

        User_24133061 user =
                new User_24133061(
                        username,
                        password,
                        phone,
                        fullname,
                        email,
                        admin,
                        active,
                        null
                );

        String action =
                req.getParameter("action");

        if ("update".equals(action)) {
            service.update(user);
        } else {
            service.insert(user);
        }

        resp.sendRedirect(
                req.getContextPath() + "/users");
    }
}