package vn.iotstar.controllers;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import vn.iotstar.entity.User_24133061;

@WebServlet("/admin/home")
public class AdminController_24133061 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession(false);

		if (session == null || session.getAttribute("account") == null) {

			resp.sendRedirect(req.getContextPath() + "/login");
			return;
		}

		User_24133061 user = (User_24133061) session.getAttribute("account");

		if (!user.isAdmin()) {

			resp.sendRedirect(req.getContextPath() + "/home");
			return;
		}

		req.getRequestDispatcher("/WEB-INF/views/admin/home.jsp").forward(req, resp);
	}
}