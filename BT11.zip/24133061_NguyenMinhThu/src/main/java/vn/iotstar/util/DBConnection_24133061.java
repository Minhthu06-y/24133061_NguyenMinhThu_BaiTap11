package vn.iotstar.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection_24133061 {

	private static final String URL = "jdbc:sqlserver://localhost\\SQLEXPRESS;" + "databaseName=WebVideo;"
			+ "encrypt=true;" + "trustServerCertificate=true";

	private static final String USER = "sa";
	private static final String PASSWORD = "sa@123456";

	public static Connection getConnection() throws SQLException {

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return DriverManager.getConnection(URL, USER, PASSWORD);
	}
}