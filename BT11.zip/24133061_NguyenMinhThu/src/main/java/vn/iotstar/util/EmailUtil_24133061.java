package vn.iotstar.util;

import java.util.Properties;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

public class EmailUtil_24133061 {

	private static final String FROM_EMAIL = "nmthu0807@gmail.com";

	private static final String APP_PASSWORD = "aqshiyeltusvhcge";

	public static void sendOTP(String toEmail, String otp) throws Exception {

		Properties props = new Properties();

		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props, new Authenticator() {

			@Override
			protected PasswordAuthentication getPasswordAuthentication() {

				return new PasswordAuthentication(FROM_EMAIL, APP_PASSWORD);
			}
		});

		Message message = new MimeMessage(session);

		message.setFrom(new InternetAddress(FROM_EMAIL));

		message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));

		message.setSubject("Ma OTP dang ky Web Video");

		message.setText("Ma OTP cua ban la: " + otp + "\n\nMa OTP co hieu luc trong phien dang ky.");

		Transport.send(message);
	}
}