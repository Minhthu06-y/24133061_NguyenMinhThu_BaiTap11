package vn.iotstar.entity;

import java.math.BigDecimal;

public class CartItem_24133061 {
	private final Video_24133061 video;
	private final String videoId;
	private final int quantity;

	public CartItem_24133061(Video_24133061 video, int quantity) {
		this(video == null ? null : video.getVideoId(), video, quantity);
	}

	public CartItem_24133061(String videoId, Video_24133061 video, int quantity) {
		this.videoId = videoId;
		this.video = video;
		this.quantity = quantity;
	}

	public Video_24133061 getVideo() {
		return video;
	}

	public int getQuantity() {
		return quantity;
	}

	public String getVideoId() {
		return videoId;
	}

	public boolean isAvailable() {
		return video != null && video.getPrice() != null && video.getPrice().signum() > 0;
	}

	public String getProductName() {
		return isAvailable() ? video.getTitle() : "Sản phẩm không khả dụng";
	}

	public String getPoster() {
		return isAvailable() ? video.getPoster() : "";
	}

	public BigDecimal getUnitPrice() {
		return isAvailable() ? video.getPrice() : null;
	}

	public BigDecimal getLineTotal() {
		return isAvailable() ? video.getPrice().multiply(BigDecimal.valueOf(quantity)) : BigDecimal.ZERO;
	}
}
