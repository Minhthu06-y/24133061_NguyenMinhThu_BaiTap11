package vn.iotstar.entity;

import java.math.BigDecimal;

public class OrderReceipt_24133061 {
	private final long orderId;
	private final BigDecimal totalAmount;

	public OrderReceipt_24133061(long orderId, BigDecimal totalAmount) {
		this.orderId = orderId;
		this.totalAmount = totalAmount;
	}

	public long getOrderId() {
		return orderId;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}
}
