/*
 * Chay script nay tren database WebVideo truoc khi su dung gio hang/COD.
 * Muc gia mac dinh 100.000 VND la gia mau; hay cap nhat theo gia ban thuc te.
 */

IF COL_LENGTH('dbo.Videos', 'Price') IS NULL
BEGIN
	ALTER TABLE dbo.Videos
	ADD Price DECIMAL(18, 2) NOT NULL
		CONSTRAINT DF_Videos_Price DEFAULT (100000);
END;
GO

IF OBJECT_ID('dbo.Orders', 'U') IS NULL
BEGIN
	CREATE TABLE dbo.Orders (
		OrderId BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY,
		CustomerName NVARCHAR(100) NOT NULL,
		Phone NVARCHAR(20) NOT NULL,
		ShippingAddress NVARCHAR(500) NOT NULL,
		Note NVARCHAR(1000) NOT NULL CONSTRAINT DF_Orders_Note DEFAULT (N''),
		TotalAmount DECIMAL(18, 2) NOT NULL,
		PaymentMethod NVARCHAR(20) NOT NULL CONSTRAINT DF_Orders_PaymentMethod DEFAULT (N'COD'),
		OrderStatus NVARCHAR(30) NOT NULL CONSTRAINT DF_Orders_OrderStatus DEFAULT (N'Chờ xác nhận'),
		CreatedAt DATETIME2 NOT NULL CONSTRAINT DF_Orders_CreatedAt DEFAULT (SYSUTCDATETIME()),
		CONSTRAINT CK_Orders_TotalAmount CHECK (TotalAmount >= 0),
		CONSTRAINT CK_Orders_PaymentMethod CHECK (PaymentMethod = N'COD')
	);
END;
GO

IF OBJECT_ID('dbo.OrderItems', 'U') IS NULL
BEGIN
	CREATE TABLE dbo.OrderItems (
		OrderItemId BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY,
		OrderId BIGINT NOT NULL,
		VideoId NVARCHAR(100) NOT NULL,
		ProductName NVARCHAR(255) NOT NULL,
		Quantity INT NOT NULL,
		UnitPrice DECIMAL(18, 2) NOT NULL,
		LineTotal DECIMAL(18, 2) NOT NULL,
		CONSTRAINT FK_OrderItems_Orders FOREIGN KEY (OrderId) REFERENCES dbo.Orders(OrderId),
		CONSTRAINT CK_OrderItems_Quantity CHECK (Quantity BETWEEN 1 AND 99),
		CONSTRAINT CK_OrderItems_UnitPrice CHECK (UnitPrice >= 0),
		CONSTRAINT CK_OrderItems_LineTotal CHECK (LineTotal >= 0)
	);
	CREATE INDEX IX_OrderItems_OrderId ON dbo.OrderItems(OrderId);
END;
GO
